import User from "../models/User.js";

/**
 * 👤 USER SIGNUP (Profile Creation)
 * Firebase user must already exist
 */
export const signupUser = async (req, res) => {
  try {
    const {
      fullName,
      phone,
      address,
      dob,
      bankDetails,
    } = req.body;

    // req.user comes from auth middleware (firebase verified)
    const { firebaseUid, email } = req.user;

    // Prevent duplicate signup
    const existingUser = await User.findOne({ firebaseUid });
    if (existingUser) {
      return res.status(400).json({
        message: "User already registered",
      });
    }

    const user = await User.create({
      firebaseUid,
      email,
      role: "user",
      fullName,
      phone,
      address,
      dob,
      bankDetails,
      isFirstLogin: false,
    });

    res.status(201).json({
      message: "User signup completed successfully",
      user,
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * 👤 USER: View own profile
 */
export const getUserProfile = async (req, res) => {
  res.json(req.user);
};

/**
 * 👤 USER: Update profile
 */
export const updateUserProfile = async (req, res) => {
  try {
    const updates = req.body;

    const user = await User.findByIdAndUpdate(
      req.user._id,
      {
        ...updates,
        isFirstLogin: false, // 🔥 mark onboarding complete
      },
      { new: true }
    );

    res.json({
      message: "Profile updated successfully",
      user,
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

