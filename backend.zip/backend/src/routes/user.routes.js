import express from "express";
import { authenticate } from "../middleware/auth.middleware.js";
import { authorizeRoles } from "../middleware/role.middleware.js";
import {
  signupUser,
  getUserProfile,
  updateUserProfile,
} from "../controllers/user.controller.js";

const router = express.Router();

/**
 * 👤 User Signup (after Firebase signup)
 */
router.post(
  "/signup",
  authenticate,
  authorizeRoles("user"),
  signupUser
);

/**
 * 👤 Get profile
 */
router.get(
  "/profile",
  authenticate,
  authorizeRoles("user"),
  getUserProfile
);

/**
 * 👤 Update profile
 */
router.put(
  "/profile",
  authenticate,
  authorizeRoles("user"),
  updateUserProfile
);

export default router;
